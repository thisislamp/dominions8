# TODO list

## Features to add
- ???

## Things to change/refactor

### Code
- De-duplicate unit related code


## Bugs

### Gameplay
- Tower projectiles can clip a unit to the side but don't disappear
